/*
 * UIExampleBitmapMaskScreen.java
 *
 * Research In Motion Limited proprietary and confidential
 * Copyright Research In Motion Limited, 2012-2012
 */

package com.samples.toolkit.ui.test;




/**
 * 
 */
class UIExampleBitmapMaskScreen {
    UIExampleBitmapMaskScreen() {
    }
}
